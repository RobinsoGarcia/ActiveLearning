The codes were used with a structure of folders that pre-existed in my computer. Thus the main script will ask for folders that won't exist on a third party computer. I haven't organized an implementation that creates all folder automatically, but I'm attaching the files to illustrate the ideas.

The main archive is active.py which is a class that does all active learning work. This is a work in progress but for the purpose of the final project, it has all implementations ready to go. Since providing these files werent required I haven't added explanations. However, looking at the paper's diagram, the main file, and the active class should give a good idea of whats happening in the background.

Again there are implementations on this file that goes beyond the scope of the project. For instance, there is a function called clustering, which is a preliminary test on using data structuring, bagging and stochastic method to select new queries (please disregard, though it is working).

Thanks for the patience and comprehension, it has been a great course that led me to a new passion. 

Robinson

